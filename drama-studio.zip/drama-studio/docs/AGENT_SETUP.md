# DRAMA Studio: configuración para agentes

## Secretos (solo servidor)

La integración lee **MUAPI_API_KEY** desde `env` de `cloudflare:workers`, exclusivamente en `app/api/studio/route.ts`. No existe formulario para usuarios ni se aceptan claves por API. Las cookies antiguas `drama_muapi` se ignoran. No guardar claves en código, commits, Markdown, capturas, logs, localStorage, variables NEXT_PUBLIC_* ni mensajes del chat.

En Sites: usar `sites_update_environment_variables` para el proyecto definido en `.openai/hosting.json`, con `set_values` que incluya `key: "MUAPI_API_KEY"`, el valor obtenido mediante un canal seguro autorizado e **is_secret: true**. Publicar una versión guardada para aplicar la revisión. Nunca copiar el valor a este documento. En desarrollo se puede usar el archivo local ignorado por Git `.dev.vars`; comprobar su exclusión antes de escribir valores reales. No inferir ni inventar una clave. La app devuelve 503 si falta el secreto.

Para abonos, configurar también **DRAMA_CREDITS_ADMIN_TOKEN**, aleatorio criptográficamente seguro, de al menos 32 caracteres, como secreto del servidor. Es un privilegio administrativo: nunca incluirlo en el navegador ni en un checkout. Sin este secreto los abonos permanecen deshabilitados. No hay créditos gratuitos ni saldo inicial implícito.

## Créditos

100 créditos DRAMA representan USD 1 de costo API. Se almacenan enteros: 10,000 unidades internas = 1 crédito. Las cotizaciones se obtienen de MuAPI con el payload exacto, vencen en cinco minutos y se vuelven a comprobar antes de enviar.

`lib/wallet.ts` reserva el importe y reclama la cotización dentro de una transacción D1 batch. El saldo se comprueba con SQL en la misma operación, incluso entre solicitudes simultáneas. Solo una reclamación puede enviar la generación. Se registra la petición antes de llamar al proveedor. Sin fondos no se llama a generación.

El usuario paga el importe cotizado: un costo real mayor del proveedor lo absorbe el negocio. Confirmar el consumo no descuenta otra vez. Un rechazo definitivo sin cargo o un reembolso confirmado del proveedor devuelve exactamente la reserva original, una sola vez. Fallos de red o estados ambiguos mantienen la reserva y nunca reintentan automáticamente la generación. Las solicitudes antiguas sin reserva no descuentan retroactivamente.

API de consulta: `GET /api/studio?action=balance` requiere identidad Sites y devuelve `balance`, `reserved`, `userId` y los últimos 30 movimientos. El cliente no puede escoger a otro usuario para consultar su saldo.

## Abonos autorizados e integración de pagos pendiente

`POST /api/credits/grant` exige `Authorization: Bearer <DRAMA_CREDITS_ADMIN_TOKEN>` y JSON:

```json
{"userId":"ID_ESTABLE_DE_SITES", "eventId":"identificador-unico-del-abono", "credits":500}
```

Obtener el ID real de `balance.userId` (también aparece en Movimientos). No usar un correo, nombre o ID inventado. `eventId` acepta letras, números, guion, guion bajo y dos puntos (máximo 150 caracteres). Usar siempre el mismo ID para reintentar el mismo abono. Repetirlo no duplica el saldo; cambiar usuario o importe con el mismo ID se rechaza. No llamar al endpoint directamente desde la web pública.

Esto es un mecanismo administrativo de abono, **no un webhook de Stripe ni de Paddle**. Antes de activar pagos: implementar y verificar la firma del webhook con la librería oficial, confirmar pago liquidado y producto/importe/moneda en servidor, mapear el cliente de pagos al ID Sites guardado en servidor, asignar créditos según un catálogo de precios autorizado y deduplicar cada factura/período. No confiar en `userId`, créditos o estado de pago enviado por el navegador. Nunca conceder créditos por visitar la URL de éxito del checkout. Implementar contracargos, devoluciones y renovaciones antes del lanzamiento comercial.

Propuesta mensual: Inicio 500 cr./299 MXN, Creador 1,300 cr./699 MXN, Estudio 3,000 cr./1,499 MXN. La calculadora conserva comisiones Stripe y supuestos editables. Guardar esa propuesta no modifica abonos, productos Stripe ni derechos de usuarios. Los abonos actuales no caducan y se acumulan; no existe aún una renovación automática, vencimiento mensual ni checkout.

## Modelos activos

- Seedance 2.5: imágenes y videos de referencia.
- Wan 3.0: solo imágenes de referencia.
- Seedance 2.5 Extend: solo video de referencia.

El catálogo permite únicamente esos tres modelos, también en servidor. Formato, resolución y duración se validan contra el catálogo oficial. Los registros históricos se conservan.

## Publicación y pruebas

Conservar bindings DB y BUCKET. Aplicar las migraciones de `drizzle/` al publicar. No borrar tablas ni recrear saldos. Probar fondos insuficientes, dos solicitudes compitiendo por saldo, reintento de cotización, abono duplicado/conflictivo, confirmación y reembolso repetidos. Las pruebas de créditos no deben consumir la API de generación ni cargar una tarjeta real.
