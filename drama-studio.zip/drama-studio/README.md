# DRAMA Studio

Estudio privado con galería de bienvenida y tres modelos: Seedance 2.5, Wan 3.0 y Seedance 2.5 Extend.

- Generación en `/estudio`; referencias y parámetros específicos de cada modelo.
- Videos de ejemplo persistentes en R2; proporciones originales y subidas de hasta 50 MB.
- Saldo DRAMA en D1: abonos administrativos, reservas atómicas, confirmación y devoluciones idempotentes.
- Cotización antes de generar; sin fondos no se envía una generación.
- `/membresias`: simulador de rentabilidad con Stripe/Paddle; pagos y renovaciones todavía no conectados.
- Clave MuAPI exclusivamente como secreto del servidor, sin formulario ni cookies de configuración.

Ver `docs/AGENT_SETUP.md` para configurar secretos, abonar créditos, integrar futuros pagos y publicar las migraciones. Los prompts predeterminados siguen pendientes.
