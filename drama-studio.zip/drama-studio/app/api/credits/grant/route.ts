import {env} from 'cloudflare:workers';
import {grantCredits} from '@/lib/wallet';
export const dynamic='force-dynamic';
async function equalSecret(a:string,b:string){const digest=(s:string)=>crypto.subtle.digest('SHA-256',new TextEncoder().encode(s));const [x,y]=await Promise.all([digest(a),digest(b)]);const u=new Uint8Array(x),v=new Uint8Array(y);let diff=0;for(let i=0;i<u.length;i++)diff|=u[i]^v[i];return diff===0;}
export async function POST(req:Request){
 const secret=(env as any).DRAMA_CREDITS_ADMIN_TOKEN;
 if(!secret||secret.length<32)return Response.json({error:'Abonos no configurados.'},{status:503});
 const auth=req.headers.get('authorization')||'';
 if(!auth.startsWith('Bearer ')||!await equalSecret(auth.slice(7),secret))return Response.json({error:'No autorizado.'},{status:401});
 try{const b:any=await req.json();if(typeof b.userId!=='string'||!b.userId.trim()||b.userId.length>200||typeof b.eventId!=='string'||!/^[-a-zA-Z0-9_:]{1,150}$/.test(b.eventId)||typeof b.credits!=='number'||!Number.isFinite(b.credits)||b.credits<=0||b.credits>1000000)throw Error('Abono no válido.');const units=Math.round(b.credits*10000);if(units<1||Math.abs(units/10000-b.credits)>1e-9)throw Error('Usa un máximo de cuatro decimales.');return Response.json(await grantCredits(encodeURIComponent(b.userId),b.eventId,units),{headers:{'Cache-Control':'no-store'}})}catch(e){return Response.json({error:(e as Error).message},{status:400})}
}
