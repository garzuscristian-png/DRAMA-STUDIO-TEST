import {env} from 'cloudflare:workers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {buildPayload,Job} from '@/lib/models';
import {saveQuote,readQuote,saveJob,recentJobs} from '@/lib/credit-store';
import {upstream,liveModels,estimate,keyHash,quoteDisplay,reconcileBilling,MuError} from '@/lib/muapi';
import {scenarioSchema,defaultScenario} from '@/lib/memberships';
import {wallet,reserveAndClaim,reconcileWallet} from '@/lib/wallet';
export const dynamic='force-dynamic';
function bucket(){const b=env.BUCKET;if(!b)throw Error('El almacenamiento no está disponible.');return b;}
function reply(data:unknown,status=200){return Response.json(data,{status,headers:{'Cache-Control':'no-store'}})}
async function identity(){const u=await getChatGPTUser();if(!u)throw Error('Inicia sesión para usar el estudio.');return encodeURIComponent(u.userId);}
async function key(){return (env as any).MUAPI_API_KEY||'';}
async function listJobs(owner:string){const prefix=`jobs/${owner}/`;const list=await bucket().list({prefix,limit:200});const old=await Promise.all(list.objects.map(async o=>(await bucket().get(o.key))?.json<Job>()));const jobs=[...await recentJobs(owner),...old.filter(Boolean) as Job[]];return [...new Map(jobs.map(j=>[j.id,j])).values()].sort((a,b)=>b.created.localeCompare(a.created));}
export async function GET(req:Request){try{
 const owner=await identity(),url=new URL(req.url),action=url.searchParams.get('action');
 if(action==='business'){const obj=await bucket().get(`business/${owner}.json`);return reply(obj?await obj.json():defaultScenario);}
 if(action==='config')return reply({configured:!!await key()});
 if(action==='catalog')return reply(await liveModels());
 if(action==='balance')return reply(await wallet(owner));
 const id=url.searchParams.get('id');if(!id)return reply(await listJobs(owner));
 if(!/^[a-zA-Z0-9-]+$/.test(id))return reply({error:'Identificador no válido.'},400);
 const entry=await readQuote(owner,id);const legacy=entry?null:await bucket().get(`jobs/${owner}/${id}.json`);const job:Job|null=entry?.job?JSON.parse(entry.job):legacy?await legacy.json<Job>():null;
 if(!job)return reply({error:entry?'Solicitud pendiente de confirmación. Revisa MuAPI antes de repetirla.':'No se encontró la generación.'},404);
 const k=await key();if(entry&&await keyHash(k)!==entry.key_hash)return reply(job);
 // Terminal failures may later be refunded; manual refresh reconciles that charge too.
 if(job.requestId&&k){const result=await upstream('/predictions/'+encodeURIComponent(job.requestId)+'/result',k);const data=result.data;job.status=data.status||job.status;const outputs=data.outputs??(data.output?.video?[data.output.video]:data.output?.image_url?[data.output.image_url]:undefined);if(Array.isArray(outputs))job.outputs=outputs.map((x:any)=>typeof x==='string'?x:x?.url).filter((x:any)=>typeof x==='string'&&x.startsWith('https://'));if(data.error)job.error=String(data.error).slice(0,500);job.billing=reconcileBilling(job.billing,result.cost);
 if(entry){await saveJob(owner,job);await reconcileWallet(owner,job);}else await bucket().put(`jobs/${owner}/${id}.json`,JSON.stringify(job));}
 return reply(job);
 }catch(e){return reply({error:(e as Error).message},400)}}
export async function POST(req:Request){try{
 const owner=await identity();if(req.headers.get('origin')!==new URL(req.url).origin)return reply({error:'Origen no permitido.'},403);
 const action=new URL(req.url).searchParams.get('action');
 if(action==='business'){const parsed=scenarioSchema.safeParse(await req.json());if(!parsed.success)return reply({error:'Revisa los importes y porcentajes de la propuesta.'},400);await bucket().put(`business/${owner}.json`,JSON.stringify(parsed.data));return reply({saved:true});}
 if(action==='config'||action==='disconnect')return reply({error:'Esta operación ya no está disponible.'},410);
 const k=await key();if(!k)return reply({error:'La generación todavía no está habilitada. Contacta al administrador.'},503);
 if(action==='upload'){if(Number(req.headers.get('content-length'))>22*1024*1024)throw Error('El archivo supera 20 MB.');const form=await req.formData();const file=form.get('file');if(!(file instanceof File)||!['image/jpeg','image/png','image/webp','video/mp4','video/quicktime'].includes(file.type))throw Error('Usa JPG, PNG, WebP, MP4 o MOV.');if(file.size>(file.type.startsWith('image/')?10:20)*1024*1024)throw Error('Máximo: imágenes 10 MB; videos 20 MB.');const body=new FormData();body.set('file',file);const {data}=await upstream('/upload_file',k,{method:'POST',body});if(typeof data.url!=='string'||!data.url.startsWith('https://'))throw Error('MuAPI no devolvió un enlace válido.');return reply({url:data.url});}
 const body:any=await req.json();
 if(action==='quote'){
  const {m,p}=buildPayload(body,await liveModels());const usd=await estimate(m,p),id=crypto.randomUUID(),expires=Date.now()+5*60000;
  await saveQuote({id,owner,key_hash:await keyHash(k),model:m.id,payload:JSON.stringify(p),estimated_micros:Math.round(usd*1e6),created:Date.now(),expires,state:'quoted',job:null});
  return reply(quoteDisplay(id,usd,p,expires));
 }
 if(action!=='generate')return reply({error:'Primero calcula los créditos de esta generación.'},400);
 const q=typeof body.quoteId==='string'?await readQuote(owner,body.quoteId):null;if(!q)throw Error('Cotización no válida. Calcula los créditos de nuevo.');
 if(q.key_hash!==await keyHash(k))throw Error('La cuenta cambió. Calcula una nueva cotización.');
 if(q.state!=='quoted'){if(q.job)return reply(JSON.parse(q.job));return reply({error:'Esta solicitud ya se envió. No se repetirá el cobro. Revisa Mis generaciones.'},409);}
 if(q.expires<Date.now())throw Error('La cotización venció. Calcula los créditos de nuevo.');
 const registry=await liveModels(),m=registry.find(m=>m.id===q.model);if(!m?.enabled)throw Error('Modelo no disponible.');const p=JSON.parse(q.payload);
 const currentUsd=await estimate(m,p);if(Math.round(currentUsd*1e6)!==q.estimated_micros)return reply({error:'MuAPI cambió el precio. Calcula una nueva cotización antes de generar.'},409);
 if(!await reserveAndClaim(owner,q.id))return reply({error:'Saldo insuficiente o solicitud ya procesada. Actualiza tus créditos antes de continuar.'},409);
 const job:Job={id:q.id,model:m.id,prompt:p.prompt,created:new Date().toISOString(),status:'submitting',outputs:[],billing:{quoteId:q.id,estimatedUsd:currentUsd,state:'estimated'},settings:{duration:p.duration,resolution:p.resolution,ratio:p.aspect_ratio,quality:p.quality}};
 // Persist before a paid call. A claimed request is never automatically resubmitted.
 try{await saveJob(owner,job);}catch(e){job.billing!.state='rejected';await reconcileWallet(owner,job);throw e;}
 try{const result=await upstream('/'+m.id,k,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(p)});const data=result.data;job.billing=reconcileBilling(job.billing,result.cost);if(!data.request_id)throw new MuError('MuAPI no devolvió el ID. Revisa su historial antes de repetir.');job.requestId=String(data.request_id);job.status=data.status||'processing';}
 catch(e){const knownRejection=e instanceof MuError&&[400,401,402,403,404,422,429].includes(e.status);job.status=knownRejection?'failed':'unknown';job.error=(e as Error).message;if(job.billing?.actualUsd===undefined)job.billing!.state=knownRejection?'rejected':'unknown';}
 try{await saveJob(owner,job);await reconcileWallet(owner,job);}catch{return reply({...job,warning:'MuAPI recibió la solicitud, pero no se pudo guardar la respuesta. Conserva el ID; no vuelvas a generar.'});}
 return reply(job);
 }catch(e){return reply({error:(e as Error).message},400)}}
