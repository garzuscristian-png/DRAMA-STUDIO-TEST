import {env} from 'cloudflare:workers';
import {getChatGPTUser,chatGPTSignInPath} from '@/app/chatgpt-auth';
export const dynamic='force-dynamic';
const MAX=50*1024*1024;
class SessionRequired extends Error {}
function failure(e:unknown){if(e instanceof SessionRequired)return json({error:e.message,code:'SESSION_REQUIRED',signInUrl:chatGPTSignInPath('/#ejemplos')},401);console.error('examples_request_failed',e instanceof Error?e.message:'Unknown error');return json({error:(e as Error).message},400);}
async function context(){const user=await getChatGPTUser();if(!user)throw new SessionRequired('Vuelve a iniciar sesión con ChatGPT para cargar y subir tus videos.');if(!env.BUCKET)throw Error('Almacenamiento no disponible.');return {bucket:env.BUCKET,prefix:`examples/${encodeURIComponent(user.userId)}/`};}
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
const validId=(id:string)=>/^[a-f0-9-]{36}$/.test(id);
export async function GET(req:Request){try{
 const {bucket,prefix}=await context(),url=new URL(req.url),id=url.searchParams.get('id');
 if(id){if(!validId(id))return json({error:'Video no válido.'},400);
  const head=await bucket.head(prefix+id);if(!head)return json({error:'Video no encontrado.'},404);
  const headers=new Headers({'Content-Type':head.httpMetadata?.contentType||'video/mp4','Accept-Ranges':'bytes','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'});
  const range=req.headers.get('range');let offset=0,length=head.size,status=200;
  if(range){const match=/^bytes=(\d*)-(\d*)$/.exec(range);if(!match||(!match[1]&&!match[2]))return new Response(null,{status:416,headers:{'Content-Range':`bytes */${head.size}`}});
   if(!match[1]){length=Math.min(Number(match[2]),head.size);offset=head.size-length;}else{offset=Number(match[1]);const end=match[2]?Math.min(Number(match[2]),head.size-1):head.size-1;length=end-offset+1;}
   if(!Number.isSafeInteger(offset)||!Number.isSafeInteger(length)||offset>=head.size||length<=0)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${head.size}`}});
   status=206;headers.set('Content-Range',`bytes ${offset}-${offset+length-1}/${head.size}`);
  }
  const obj=await bucket.get(prefix+id,{range:{offset,length}});if(!obj)return json({error:'Video no encontrado.'},404);headers.set('Content-Length',String(length));return new Response(obj.body,{status,headers});
 }
 const listed=await bucket.list({prefix,limit:100,cursor:url.searchParams.get('cursor')||undefined,include:['customMetadata']} as any);
 return json({items:listed.objects.map(o=>({id:o.key.slice(prefix.length),name:o.customMetadata?.name||'Video de ejemplo',width:Number(o.customMetadata?.width)||0,height:Number(o.customMetadata?.height)||0,created:o.uploaded.toISOString(),size:o.size})),cursor:listed.truncated?listed.cursor:null});
}catch(e){return failure(e)}}
export async function POST(req:Request){try{
 const {bucket,prefix}=await context();if(req.headers.get('origin')!==new URL(req.url).origin)return json({error:'Origen no permitido.'},403);
 if(Number(req.headers.get('content-length'))>MAX+1024*1024)return json({error:'Cada video debe pesar hasta 50 MB.'},413);
 const form=await req.formData(),file=form.get('file');if(!(file instanceof File)||!(/\.(mp4|webm|mov)$/i.test(file.name)||['video/mp4','video/webm','video/quicktime'].includes(file.type))||!file.size||file.size>MAX)throw Error('Sube un video MP4, WebM o MOV de hasta 50 MB.');
 const bytes=new Uint8Array(await file.slice(0,16).arrayBuffer());const iso=String.fromCharCode(...bytes.slice(4,8))==='ftyp',webm=bytes[0]===0x1a&&bytes[1]===0x45&&bytes[2]===0xdf&&bytes[3]===0xa3;if(!webm&&!iso)throw Error('El archivo no corresponde a un video compatible.');
 const width=Number(form.get('width')),height=Number(form.get('height'));if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>32768||height>32768)throw Error('No se pudieron leer las dimensiones del video.');
 const id=crypto.randomUUID(),name=String(form.get('title')||file.name).trim().slice(0,120)||'Video de ejemplo';
 await bucket.put(prefix+id,file.stream(),{httpMetadata:{contentType:webm?'video/webm':/\.mov$/i.test(file.name)?'video/quicktime':'video/mp4'},customMetadata:{name,width:String(width),height:String(height)}});
 return json({id,name,width,height,created:new Date().toISOString(),size:file.size},201);
}catch(e){return failure(e)}}
