import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DRAMA — Estudio IA",
  description: "Crea escenas de drama con imágenes, video y seis modelos de IA.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">{children}</body>
    </html>
  );
}
