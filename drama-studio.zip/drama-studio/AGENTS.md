# DRAMA Studio

Antes de modificar generación, créditos, pagos o configuración, leer `docs/AGENT_SETUP.md`.
No exponer ni solicitar claves API en la interfaz. MUAPI_API_KEY y DRAMA_CREDITS_ADMIN_TOKEN son secretos del servidor.
Preservar transacciones D1, unidades enteras, idempotencia y aislamiento por identidad. No conceder créditos desde datos del cliente ni simular pagos exitosos.
