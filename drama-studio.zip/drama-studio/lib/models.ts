import catalog from './catalog/muapi.json';
export const CREDITS_PER_USD=100;
export const credits=(usd:number)=>Math.round(usd*1000000)/10000;
export type Model={id:string;catalogId:string;name:string;tag:string;description:string;images:number;videos:number;resolutions:string[];ratios:string[];durations:string[];qualities:string[];defaultResolution:string;defaultRatio:string;defaultDuration:string;defaultQuality:string;kind:string;audioField?:string;highBitrate:boolean;thinking:boolean;enabled:boolean;schema:any};
const metadata=[
 {catalogId:'seedance-2.5-spicy-omni-reference',name:'Seedance 2.5',tag:'SPICY',description:'Imágenes y video como punto de partida.',imageField:'images_list',videoField:'videos_list',kind:'video'},
 {catalogId:'wan3.0-spicy-reference-to-video',name:'Wan 3.0',tag:'SPICY',description:'Da movimiento a tus imágenes de referencia.',imageField:'images_list',videoField:'',kind:'video'},
 {catalogId:'seedance-2.5-spicy-video-extend',name:'Seedance 2.5 Extend',tag:'EXTEND',description:'Continúa la historia desde el último fotograma.',imageField:'',videoField:'video_url',kind:'video'},
];
export function normalizeCatalog(data:Record<string,any>):Model[]{return metadata.map(meta=>{
 const c=data[meta.catalogId],schema=c?.input_schema?.schemas?.input_data,props=schema?.properties;if(!props)throw Error('No se pudo verificar el catálogo de MuAPI.');
 const duration=props.duration;
 const durations=duration?.enum?.map(String)??(duration?Array.from({length:Math.floor((duration.maxValue-duration.minValue)/(duration.step||1))+1},(_,i)=>String(duration.minValue+i*(duration.step||1))):[]);
 if(duration&&(!durations.length||durations.length>120))throw Error('MuAPI devolvió límites de duración desconocidos.');
 const id=c.endpoint_url?.replace(/^\/api\/v1\//,'');if(!id||!/^[a-zA-Z0-9.-]+$/.test(id))throw Error('Endpoint de modelo no válido.');
 return {...meta,id,images:meta.imageField?(props[meta.imageField]?.maxItems??1):0,videos:meta.videoField?(props[meta.videoField]?.maxItems??1):0,
 resolutions:props.resolution?.enum??[],ratios:props.aspect_ratio?.enum??[],qualities:props.quality?.enum??[],durations,
 defaultResolution:props.resolution?.default??'',defaultRatio:props.aspect_ratio?.default??'',defaultDuration:duration?String(duration.default):'',defaultQuality:props.quality?.default??'',
 audioField:props.generate_audio?'generate_audio':props.enable_audio?'enable_audio':undefined,highBitrate:!!props.high_bitrate,thinking:!!props.thinking_mode,enabled:!!c.is_enabled&&!c.is_coming_soon,schema};
});}
export const models=normalizeCatalog(catalog);
export type Quote={id:string;usd:number;credits:number;unit:'second'|'image';unitUsd:number;unitCredits:number;duration?:number;expires:number;signature?:string};
export type Billing={estimatedUsd:number;actualUsd?:number;nativeCredits?:number;refunded?:boolean;state:'estimated'|'charged'|'refunded'|'unknown'|'rejected';quoteId:string};
export type Job={id:string;requestId?:string;model:string;prompt:string;created:string;status:string;outputs:string[];error?:string;billing?:Billing;settings?:{duration?:number;resolution?:string;ratio?:string;quality?:string}};
export function buildPayload(b:any,registry:Model[]=models){
 const m=registry.find(m=>m.id===b.model);if(!m||!m.enabled)throw Error('Modelo no disponible.');
 if(typeof b.prompt!=='string'||!b.prompt.trim()||b.prompt.length>12000)throw Error('Escribe un prompt de hasta 12,000 caracteres.');
 const images=b.images??[],videos=b.videos??[];
 if(!Array.isArray(images)||!Array.isArray(videos)||images.length>m.images||videos.length>m.videos)throw Error('Las referencias no corresponden al modelo.');
 for(const u of [...images,...videos]){let url;try{url=new URL(u)}catch{throw Error('Usa enlaces HTTPS válidos.')}if(typeof u!=='string'||url.protocol!=='https:'||url.username||url.password)throw Error('Usa enlaces HTTPS válidos.');}
 if(m.tag==='EXTEND'&&videos.length!==1)throw Error('Añade el video que quieres extender.');
 const p:any={prompt:b.prompt.trim()};
 if(images.length)p.images_list=images;
 if(m.tag==='EXTEND')p.video_url=videos[0];else if(videos.length)p.videos_list=videos;
 if(m.durations.length){if(!m.durations.includes(String(b.duration)))throw Error('La duración no es válida para '+m.name+'.');p.duration=Number(b.duration);}
 if(m.resolutions.length){if(!m.resolutions.includes(b.resolution))throw Error('Resolución no válida para '+m.name+'.');p.resolution=b.resolution;}
 if(m.ratios.length){if(!m.ratios.includes(b.ratio))throw Error('Formato no válido para '+m.name+'.');p.aspect_ratio=b.ratio;}
 if(m.qualities.length){if(!m.qualities.includes(b.quality))throw Error('Calidad no válida.');p.quality=b.quality;}
 for(const [field,value] of [[m.audioField,b.audio??true],[m.highBitrate?'high_bitrate':null,b.highBitrate??false],[m.thinking?'thinking_mode':null,b.thinking??false]] as const){if(field){if(typeof value!=='boolean')throw Error('Opción no válida.');p[field]=value;}}
 if(m.id==='seedance-2.5-spicy-omni-reference')p.omni_reference_task_type='reference';
 return {m,p};
}
