import {z} from 'zod';
const amount=z.number().finite().min(0).max(10000000);
export const scenarioSchema=z.object({
 provider:z.enum(['stripe','paddle']),fx:z.number().finite().min(1).max(100),saleTax:z.number().min(0).max(40),feeVat:z.number().min(0).max(40),
 international:z.boolean(),conversion:z.boolean(),reserve:z.number().min(0).max(100),targetMargin:z.number().min(0).max(90),
 plans:z.array(z.object({id:z.string().max(30),name:z.string().min(1).max(40),price:amount,credits:amount,overhead:amount})).length(3)
});
export type Scenario=z.infer<typeof scenarioSchema>;
export const defaultScenario:Scenario={provider:'stripe',fx:20,saleTax:16,feeVat:16,international:false,conversion:false,reserve:10,targetMargin:35,plans:[
 {id:'inicio',name:'Inicio',price:299,credits:500,overhead:15},
 {id:'creador',name:'Creador',price:699,credits:1300,overhead:30},
 {id:'estudio',name:'Estudio',price:1499,credits:3000,overhead:60}
]};
export function economics(plan:Scenario['plans'][number],s:Scenario){
 const revenue=plan.price/(1+s.saleTax/100),salesTax=plan.price-revenue;
 const apiCost=plan.credits/100*s.fx,contingency=apiCost*s.reserve/100;
 const rate=s.provider==='stripe'?.036+.007+(s.international?.005:0)+(s.conversion?.02:0):.05;
 const fixed=s.provider==='stripe'?3:.5*s.fx;
 const paymentFeeBase=plan.price*rate+fixed,paymentTax=paymentFeeBase*s.feeVat/100,paymentFees=paymentFeeBase+paymentTax;
 const contribution=revenue-apiCost-contingency-plan.overhead-paymentFees;
 const margin=revenue>0?contribution/revenue*100:0;
 const denominator=(1-s.targetMargin/100)/(1+s.saleTax/100)-rate*(1+s.feeVat/100);
 const priceForMargin=denominator>0?(apiCost+contingency+plan.overhead+fixed*(1+s.feeVat/100))/denominator:null;
 return {revenue,salesTax,apiCost,contingency,paymentFeeBase,paymentTax,paymentFees,contribution,margin,priceForMargin,rate,fixed};
}
