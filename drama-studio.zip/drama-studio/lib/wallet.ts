import {env} from 'cloudflare:workers';
import type {Job} from './models';
const database=()=>{if(!env.DB)throw Error('El saldo no está disponible.');return env.DB};
// Integer USD micro-units: 10,000 units = 1 DRAMA credit.
export async function wallet(owner:string){
 const db=database();
 const total=await db.prepare('SELECT COALESCE(SUM(units),0) AS units FROM credit_ledger WHERE owner=?').bind(owner).first<{units:number}>();
 const held=await db.prepare("SELECT COALESCE(-SUM(r.units),0) AS units FROM credit_ledger r WHERE r.owner=? AND r.kind='reserve' AND NOT EXISTS (SELECT 1 FROM credit_ledger x WHERE x.event_id='capture:'||r.request_id OR x.event_id='refund:'||r.request_id)").bind(owner).first<{units:number}>();
 const history=await db.prepare('SELECT event_id,units,kind,created FROM credit_ledger WHERE owner=? ORDER BY created DESC LIMIT 30').bind(owner).all();
 return {balance:(total?.units||0)/10000,reserved:(held?.units||0)/10000,userId:decodeURIComponent(owner),history:history.results};
}
export async function reserveAndClaim(owner:string,id:string){
 const db=database(),now=Date.now();
 const results=await db.batch([
  db.prepare("INSERT OR IGNORE INTO credit_ledger(event_id,owner,units,kind,request_id,created) SELECT 'reserve:'||id,owner,-estimated_micros,'reserve',id,? FROM credit_requests WHERE id=? AND owner=? AND state='quoted' AND expires>? AND estimated_micros <= (SELECT COALESCE(SUM(units),0) FROM credit_ledger WHERE owner=?)").bind(now,id,owner,now,owner),
  db.prepare("UPDATE credit_requests SET state='submitting' WHERE id=? AND owner=? AND state='quoted' AND expires>? AND EXISTS (SELECT 1 FROM credit_ledger WHERE event_id='reserve:'||credit_requests.id AND owner=credit_requests.owner)").bind(id,owner,now),
 ]);
 return results[1].meta.changes===1;
}
export async function reconcileWallet(owner:string,job:Job){
 // Never infer refunds from failure alone: uncertain requests remain reserved.
 const refund=job.billing?.refunded || job.billing?.state==='rejected';
 const capture=!refund&&(job.billing?.actualUsd!==undefined||job.status==='completed');
 if(!refund&&!capture)return;
 const kind=refund?'refund':'capture';
 await database().prepare("INSERT OR IGNORE INTO credit_ledger(event_id,owner,units,kind,request_id,created) SELECT ?,owner,CASE WHEN ?='refund' THEN -units ELSE 0 END,?,request_id,? FROM credit_ledger WHERE event_id=? AND owner=?").bind(kind+':'+job.id,kind,kind,Date.now(),'reserve:'+job.id,owner).run();
}
export async function grantCredits(owner:string,eventId:string,units:number){
 const id='grant:'+eventId,db=database();
 const result=await db.prepare("INSERT OR IGNORE INTO credit_ledger(event_id,owner,units,kind,created) VALUES (?,?,?,'grant',?)").bind(id,owner,units,Date.now()).run();
 const existing=await db.prepare('SELECT owner,units FROM credit_ledger WHERE event_id=?').bind(id).first<{owner:string;units:number}>();
 if(existing?.owner!==owner||existing?.units!==units)throw Error('El identificador de abono ya se usó con otros datos.');
 return {applied:result.meta.changes===1,...await wallet(owner)};
}
