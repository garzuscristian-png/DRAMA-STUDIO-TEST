CREATE TABLE `credit_requests` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`key_hash` text NOT NULL,
	`model` text NOT NULL,
	`payload` text NOT NULL,
	`estimated_micros` integer NOT NULL,
	`created` integer NOT NULL,
	`expires` integer NOT NULL,
	`state` text DEFAULT 'quoted' NOT NULL,
	`job` text
);
--> statement-breakpoint
CREATE INDEX `idx_credit_requests_owner_created` ON `credit_requests` (`owner`,`created`);