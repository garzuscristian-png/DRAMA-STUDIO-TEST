CREATE TABLE `credit_ledger` (
	`event_id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`units` integer NOT NULL,
	`kind` text NOT NULL,
	`request_id` text,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_credit_ledger_owner_created` ON `credit_ledger` (`owner`,`created`);