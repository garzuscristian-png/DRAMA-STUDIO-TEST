import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const creditRequests=sqliteTable('credit_requests',{
 id:text('id').primaryKey(),owner:text('owner').notNull(),keyHash:text('key_hash').notNull(),model:text('model').notNull(),payload:text('payload').notNull(),
 estimatedMicros:integer('estimated_micros').notNull(),created:integer('created').notNull(),expires:integer('expires').notNull(),state:text('state').notNull().default('quoted'),job:text('job'),
},t=>[index('idx_credit_requests_owner_created').on(t.owner,t.created)]);

export const creditLedger=sqliteTable('credit_ledger',{
 eventId:text('event_id').primaryKey(),owner:text('owner').notNull(),units:integer('units').notNull(),kind:text('kind').notNull(),requestId:text('request_id'),created:integer('created').notNull(),
},t=>[index('idx_credit_ledger_owner_created').on(t.owner,t.created)]);
